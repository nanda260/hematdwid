<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/webauthn.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

function webauthnLoginFail(string $message): void
{
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = trim($input['email'] ?? '');

if ($email === '') {
    webauthnLoginFail('Email wajib diisi.');
}

$pdo = getConnection();
$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    webauthnLoginFail('Akun tidak ditemukan atau belum mendaftarkan sidik jari.');
}

$stmt = $pdo->prepare('SELECT credential_id FROM webauthn_credentials WHERE user_id = ?');
$stmt->execute([$user['id']]);
$creds = $stmt->fetchAll();

if (!$creds) {
    webauthnLoginFail('Akun ini belum mendaftarkan sidik jari.');
}

$challenge = webauthnGenerateChallenge('login');
$_SESSION['webauthn_login_user_id'] = $user['id'];

echo json_encode([
    'challenge'         => base64url_encode($challenge),
    'rpId'              => webauthnRpId(),
    'timeout'           => 60000,
    'userVerification'  => 'required',
    'allowCredentials'  => array_map(function ($c) {
        return ['type' => 'public-key', 'id' => base64url_encode($c['credential_id'])];
    }, $creds),
]);